<?php
/**
 * Temporary Optimization Script for Plesk
 * 
 * INSTRUCTIONS:
 * 1. Upload this file to your domain root
 * 2. Access via browser: https://yourdomain.com/optimize.php
 * 3. DELETE this file immediately after use!
 * 
 * SECURITY WARNING: This file allows running artisan commands via web.
 * Remove it immediately after use!
 */

// Security check
if (!isset($_GET['run']) || $_GET['run'] !== 'optimize') {
    die('Access denied. Add ?run=optimize to URL to proceed.');
}

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

echo "<h2>Optimizing Laravel...</h2>";
echo "<pre>";

try {
    echo "Caching configuration...\n";
    Artisan::call('config:cache');
    echo Artisan::output();
    
    echo "\nCaching routes...\n";
    Artisan::call('route:cache');
    echo Artisan::output();
    
    echo "\nCaching views...\n";
    Artisan::call('view:cache');
    echo Artisan::output();
    
    echo "\nCaching events...\n";
    Artisan::call('event:cache');
    echo Artisan::output();
    
    echo "\n✅ Optimization completed successfully!\n";
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "\nStack trace:\n";
    echo $e->getTraceAsString();
}

echo "</pre>";
echo "<p><strong>⚠️ IMPORTANT: Delete this file (optimize.php) immediately!</strong></p>";

