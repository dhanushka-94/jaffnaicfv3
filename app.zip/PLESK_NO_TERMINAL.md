# Deploying to Plesk Without Terminal Access

This guide is for deploying Laravel to Plesk when you only have file upload access (FTP/File Manager) and no SSH/terminal access.

## Prerequisites

- Local development environment with Composer and Node.js installed
- FTP access or Plesk File Manager access
- Plesk control panel access

## Step 1: Prepare Everything Locally

### 1.1 Install Dependencies Locally

On your local machine, run:

```bash
# Install Composer dependencies (production)
composer install --optimize-autoloader --no-dev

# Install Node.js dependencies
npm install

# Build production assets
npm run build
```

### 1.2 Prepare .env File

Create your `.env` file locally with production settings:

```env
APP_NAME="JAFFNA ICF"
APP_ENV=production
APP_KEY=base64:YOUR_GENERATED_KEY_HERE
APP_DEBUG=false
APP_TIMEZONE=Asia/Colombo
APP_URL=https://yourdomain.com

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=your_plesk_database_name
DB_USERNAME=your_plesk_database_user
DB_PASSWORD=your_plesk_database_password

SESSION_DRIVER=database
SESSION_LIFETIME=120

CACHE_STORE=database
QUEUE_CONNECTION=database
FILESYSTEM_DISK=local

# ... other settings from .env.example
```

**Generate APP_KEY locally:**
```bash
php artisan key:generate
```
Copy the generated key to your `.env` file.

## Step 2: Files to Upload

### 2.1 Upload These Files/Folders

Upload ALL files and folders EXCEPT:

**❌ DO NOT UPLOAD:**
- `.git/` folder
- `.gitignore`
- `node_modules/` folder
- `.env.example` (optional, can upload for reference)
- `composer.json` and `composer.lock` (optional, but recommended to keep)
- `package.json` and `package-lock.json` (optional, but recommended to keep)
- `build-production.sh` and `build-production.bat` (optional)
- Development documentation files (optional)

**✅ MUST UPLOAD:**
- `app/` - Application code
- `bootstrap/` - Bootstrap files
- `config/` - Configuration files
- `database/` - Migrations and seeders
- `public/` - Public files (including `build/` folder with assets)
- `resources/` - Views and assets source
- `routes/` - Route definitions
- `storage/` - Storage directory (must be writable)
- `vendor/` - Composer dependencies (installed locally)
- `.env` - Environment file (with production settings)
- `artisan` - Laravel command-line tool
- `composer.json` and `composer.lock` - Dependency definitions

### 2.2 Upload Structure

Your Plesk directory structure should look like:

```
/domains/yourdomain.com/
├── app/
├── bootstrap/
├── config/
├── database/
├── public/          ← Set this as document root in Plesk
│   ├── build/       ← Contains compiled assets
│   ├── index.php
│   ├── .htaccess
│   └── ...
├── resources/
├── routes/
├── storage/         ← Must be writable
├── vendor/          ← Composer packages
├── .env             ← Your production config
├── artisan
└── composer.json
```

## Step 3: Configure Plesk via Web Interface

### 3.1 Set Document Root

1. Login to Plesk
2. Go to **Domains** → **yourdomain.com**
3. Click **Hosting Settings**
4. Set **Document root** to: `httpdocs/public` or `public_html/public`
   - Or the full path: `/var/www/vhosts/yourdomain.com/httpdocs/public`
5. Save changes

### 3.2 Create Database

1. Go to **Databases** → **Add Database**
2. Create a new MySQL database
3. Note down:
   - Database name
   - Database username
   - Database password
4. Update your `.env` file with these credentials
5. Re-upload the updated `.env` file

### 3.3 Configure PHP

1. Go to **PHP Settings**
2. Select **PHP 8.2** or higher
3. Enable these extensions:
   - `pdo_mysql`
   - `mbstring`
   - `xml`
   - `ctype`
   - `json`
   - `zip`
   - `gd` or `imagick`
   - `fileinfo`
   - `openssl`

### 3.4 Set File Permissions (via File Manager)

1. Go to **File Manager**
2. Navigate to your domain root
3. Right-click on `storage/` folder → **Change Permissions**
   - Set to: `755` or `775`
4. Right-click on `bootstrap/cache/` folder → **Change Permissions**
   - Set to: `755` or `775`

**If File Manager doesn't allow this:**
- Contact your hosting provider to set permissions
- Or use Plesk's "Fix Permissions" feature if available

## Step 4: Run Migrations (Using Plesk Tools)

### Option A: Using Plesk's Composer (if available)

1. Go to **Websites & Domains** → **yourdomain.com**
2. Look for **Composer** or **PHP Composer** option
3. If available, you can run commands there

### Option B: Using Plesk's PHP CLI

1. Go to **Websites & Domains** → **yourdomain.com**
2. Look for **PHP CLI** or **Run PHP Script**
3. Create a temporary migration script:

Create file `run-migrations.php` in your domain root:

```php
<?php
// Temporary migration runner
// Delete this file after running migrations

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);

$kernel->bootstrap();

// Run migrations
Artisan::call('migrate', ['--force' => true]);

echo "Migrations completed!";
echo "\n";
echo Artisan::output();
```

4. Access via browser: `https://yourdomain.com/run-migrations.php`
5. **DELETE this file immediately after use!**

### Option C: Contact Hosting Provider

Ask your hosting provider to run:
```bash
php artisan migrate --force
php artisan storage:link
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## Step 5: Create Storage Link

### Option A: Via PHP Script

Create `create-storage-link.php`:

```php
<?php
// Temporary storage link creator
// Delete this file after use

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

Artisan::call('storage:link');

echo "Storage link created!";
```

Access via browser, then delete the file.

### Option B: Manual Symlink (if File Manager allows)

1. In File Manager, go to `public/` directory
2. Create a symbolic link named `storage` pointing to `../storage/app/public`
3. Or contact hosting provider to create the link

## Step 6: Optimize (Optional but Recommended)

Create `optimize.php`:

```php
<?php
// Temporary optimization script
// Delete after use

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

Artisan::call('config:cache');
Artisan::call('route:cache');
Artisan::call('view:cache');
Artisan::call('event:cache');

echo "Optimization completed!";
```

Access via browser, then delete.

## Step 7: Verify Installation

1. Visit your domain: `https://yourdomain.com`
2. Check if homepage loads
3. Visit admin panel: `https://yourdomain.com/admin`
4. Try to login

## Troubleshooting

### 500 Internal Server Error

1. Check `.env` file exists and has correct settings
2. Verify `APP_KEY` is set
3. Check file permissions on `storage/` and `bootstrap/cache/`
4. Check Plesk error logs

### Database Connection Error

1. Verify database credentials in `.env`
2. Ensure database exists in Plesk
3. Check database user has proper permissions

### Assets Not Loading

1. Verify `public/build/` folder exists and contains files
2. Check `APP_URL` in `.env` matches your domain
3. Clear browser cache

### Permission Denied Errors

1. Set `storage/` to 755 or 775
2. Set `bootstrap/cache/` to 755 or 775
3. Contact hosting provider if needed

## Security Checklist

- [ ] `.env` file has `APP_DEBUG=false`
- [ ] `.env` file has correct `APP_KEY`
- [ ] File permissions set correctly
- [ ] Temporary PHP scripts deleted
- [ ] `storage/` folder not accessible via web (check `.htaccess`)
- [ ] Database credentials are secure

## Quick Reference: Files to Upload Checklist

- [ ] `app/` folder
- [ ] `bootstrap/` folder
- [ ] `config/` folder
- [ ] `database/` folder
- [ ] `public/` folder (with `build/` subfolder)
- [ ] `resources/` folder
- [ ] `routes/` folder
- [ ] `storage/` folder (empty is OK, will be populated)
- [ ] `vendor/` folder (from local `composer install`)
- [ ] `.env` file (with production settings)
- [ ] `artisan` file
- [ ] `composer.json` and `composer.lock`

## Notes

- Upload `vendor/` folder from your local installation (it's large, ~50-100MB)
- The `public/build/` folder contains your compiled assets
- You can skip uploading `node_modules/` if you built assets locally
- Keep `composer.json` and `composer.lock` for future updates

