# Plesk Deployment Guide

## Fixing Database Connection Error During Composer Install

If you encounter this error during `composer install`:
```
SQLSTATE[HY000] [1698] Access denied for user 'root'@'localhost'
```

This happens because Laravel tries to connect to the database during `package:discover`, but the database isn't set up yet.

## Solution

### Step 1: Configure Database in Plesk

1. **Create Database in Plesk:**
   - Go to **Databases** → **Add Database**
   - Create a new MySQL database
   - Note down the database name, username, and password

2. **Update `.env` File:**
   ```env
   DB_CONNECTION=mysql
   DB_HOST=localhost
   DB_PORT=3306
   DB_DATABASE=your_plesk_database_name
   DB_USERNAME=your_plesk_database_user
   DB_PASSWORD=your_plesk_database_password
   ```

### Step 2: Install Dependencies (Skip Database Connection)

**Option A: Install without running package discovery**
```bash
composer install --no-scripts
composer dump-autoload --optimize
```

**Option B: Set temporary database config**
```bash
# Temporarily disable database in .env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_DATABASE=temp
DB_USERNAME=temp
DB_PASSWORD=temp

# Install dependencies
composer install --optimize-autoloader --no-dev

# Then update .env with correct credentials
# Run migrations
php artisan migrate --force
```

### Step 3: Run Migrations

After composer install completes:
```bash
php artisan migrate --force
```

### Step 4: Seed Database (Optional)

```bash
php artisan db:seed --class=FreshDatabaseSeeder
```

## Plesk-Specific Configuration

### 1. Document Root Setup

In Plesk, set the document root to:
```
/path/to/your/project/public
```

### 2. PHP Version

Ensure PHP >= 8.2 is selected in Plesk:
- Go to **Domains** → **yourdomain.com** → **PHP Settings**
- Select PHP 8.2 or higher

### 3. PHP Extensions Required

Enable these extensions in Plesk PHP Settings:
- `pdo_mysql`
- `mbstring`
- `xml`
- `ctype`
- `json`
- `zip`
- `gd` or `imagick`
- `fileinfo`
- `openssl`

### 4. File Permissions

Set permissions via Plesk File Manager or SSH:
```bash
chmod -R 755 storage bootstrap/cache
chown -R psacln:psacln storage bootstrap/cache
```

### 5. Storage Link

Create symbolic link for storage:
```bash
php artisan storage:link
```

### 6. Optimize for Production

```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache
```

## Common Plesk Issues

### Issue 1: Database Authentication Error

**Error:** `Access denied for user 'root'@'localhost'`

**Solution:**
- Plesk doesn't use `root` user for databases
- Use the database user created in Plesk
- Update `.env` with correct credentials

### Issue 2: Composer Install Fails

**Error:** Database connection during `package:discover`

**Solution:**
- Use `composer install --no-scripts` first
- Then run `composer dump-autoload --optimize`
- Update `.env` with correct database credentials
- Run migrations

### Issue 3: 500 Internal Server Error

**Check:**
1. `.env` file exists and is configured
2. `APP_KEY` is generated: `php artisan key:generate`
3. File permissions on `storage/` and `bootstrap/cache/`
4. Check error logs: `storage/logs/laravel.log`

### Issue 4: Assets Not Loading

**Solution:**
```bash
npm install
npm run build
```

Ensure `public/build/` directory exists and contains assets.

## Complete Plesk Deployment Steps

1. **Upload/Clone Code**
   ```bash
   git clone https://github.com/dhanushka-94/jaffnaicfv3.git
   cd jaffnaicfv3
   ```

2. **Create Database in Plesk**
   - Note database name, username, password

3. **Configure Environment**
   ```bash
   cp .env.example .env
   # Edit .env with Plesk database credentials
   ```

4. **Install Dependencies**
   ```bash
   composer install --no-scripts
   composer dump-autoload --optimize
   ```

5. **Generate App Key**
   ```bash
   php artisan key:generate
   ```

6. **Run Migrations**
   ```bash
   php artisan migrate --force
   ```

7. **Create Storage Link**
   ```bash
   php artisan storage:link
   ```

8. **Build Assets**
   ```bash
   npm install
   npm run build
   ```

9. **Set Permissions**
   ```bash
   chmod -R 755 storage bootstrap/cache
   ```

10. **Optimize**
    ```bash
    php artisan config:cache
    php artisan route:cache
    php artisan view:cache
    ```

11. **Configure Plesk**
    - Set document root to `public/`
    - Enable PHP 8.2+
    - Enable required PHP extensions

## Verification

After deployment, verify:
- [ ] Homepage loads correctly
- [ ] Admin panel accessible at `/admin`
- [ ] Can login to admin panel
- [ ] File uploads work
- [ ] Database operations work
- [ ] Assets (CSS/JS) load correctly

## Support

If issues persist:
1. Check `storage/logs/laravel.log`
2. Check Plesk error logs
3. Verify database credentials
4. Verify file permissions
5. Check PHP version and extensions

