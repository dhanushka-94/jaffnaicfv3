<?php
/**
 * Temporary Storage Link Creator for Plesk
 * 
 * INSTRUCTIONS:
 * 1. Upload this file to your domain root
 * 2. Access via browser: https://yourdomain.com/create-storage-link.php
 * 3. DELETE this file immediately after use!
 * 
 * SECURITY WARNING: This file allows running artisan commands via web.
 * Remove it immediately after use!
 */

// Security check
if (!isset($_GET['run']) || $_GET['run'] !== 'link') {
    die('Access denied. Add ?run=link to URL to proceed.');
}

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

echo "<h2>Creating Storage Link...</h2>";
echo "<pre>";

try {
    // Remove existing link if exists
    $linkPath = public_path('storage');
    if (file_exists($linkPath)) {
        if (is_link($linkPath)) {
            unlink($linkPath);
            echo "Removed existing link.\n";
        } else {
            echo "⚠️ Warning: storage exists but is not a link.\n";
        }
    }
    
    // Create storage link
    Artisan::call('storage:link');
    echo Artisan::output();
    echo "\n✅ Storage link created successfully!\n";
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "\nStack trace:\n";
    echo $e->getTraceAsString();
}

echo "</pre>";
echo "<p><strong>⚠️ IMPORTANT: Delete this file (create-storage-link.php) immediately!</strong></p>";

