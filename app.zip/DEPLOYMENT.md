# Production Deployment Guide

## Pre-Deployment Checklist

### 1. Environment Configuration
- [ ] Copy `.env.example` to `.env` on production server
- [ ] Update `.env` with production values:
  - `APP_ENV=production`
  - `APP_DEBUG=false`
  - `APP_URL=https://yourdomain.com` (your actual domain)
  - Database credentials (MySQL)
  - Mail configuration (if using email)
  - Any other production-specific settings

### 2. Server Requirements
- PHP >= 8.2
- MySQL >= 5.7 or MariaDB >= 10.3
- Composer
- Node.js >= 18 and npm (for building assets)
- Web server (Apache/Nginx)

### 3. PHP Extensions Required
- `pdo_mysql`
- `mbstring`
- `xml`
- `ctype`
- `json`
- `zip` (for Filament exports)
- `gd` or `imagick` (for image processing)
- `fileinfo`
- `openssl`

## Deployment Steps

### Step 1: Upload Files
Upload all project files to your production server (excluding `node_modules`, `.git`, etc.)

### Step 2: Install Dependencies
```bash
# Install PHP dependencies
composer install --optimize-autoloader --no-dev

# Install Node.js dependencies
npm install
```

### Step 3: Build Assets
```bash
# Build production assets
npm run build
```

### Step 4: Configure Environment
```bash
# Copy environment file
cp .env.example .env

# Generate application key
php artisan key:generate

# Edit .env file with production settings
nano .env  # or use your preferred editor
```

### Step 5: Run Migrations
```bash
# Run database migrations
php artisan migrate --force

# (Optional) Seed initial data
php artisan db:seed --class=FreshDatabaseSeeder
```

### Step 6: Create Storage Link
```bash
# Create symbolic link for storage
php artisan storage:link
```

### Step 7: Optimize for Production
```bash
# Cache configuration
php artisan config:cache

# Cache routes
php artisan route:cache

# Cache views
php artisan view:cache

# Cache events
php artisan event:cache

# Optimize autoloader (already done in step 2, but can run again)
composer dump-autoload --optimize
```

### Step 8: Set Permissions
```bash
# Set proper permissions (Linux/Unix)
chmod -R 755 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

### Step 9: Web Server Configuration

#### Apache (.htaccess)
Ensure `public/.htaccess` exists and is configured correctly.

#### Nginx Configuration Example
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /path/to/your/project/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

## Post-Deployment

### Clear All Caches (if needed)
```bash
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan event:clear
```

### Verify Installation
- [ ] Visit your domain and check if the site loads
- [ ] Test admin login at `/admin`
- [ ] Verify file uploads work (check `storage/app/public`)
- [ ] Test database operations

## Maintenance Commands

### Update Application
```bash
# Pull latest code
git pull origin main  # or your branch

# Install/update dependencies
composer install --optimize-autoloader --no-dev
npm install
npm run build

# Run migrations
php artisan migrate --force

# Clear and rebuild caches
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache
```

### Backup Database
```bash
# Create database backup
mysqldump -u username -p database_name > backup_$(date +%Y%m%d).sql
```

## Troubleshooting

### If site shows 500 error:
1. Check `.env` file exists and is configured correctly
2. Check file permissions on `storage` and `bootstrap/cache`
3. Check Laravel logs: `storage/logs/laravel.log`
4. Clear all caches and rebuild

### If assets don't load:
1. Ensure `npm run build` was executed
2. Check `public/build` directory exists
3. Verify `APP_URL` in `.env` matches your domain
4. Clear browser cache

### If database connection fails:
1. Verify database credentials in `.env`
2. Ensure MySQL service is running
3. Check database exists
4. Verify user has proper permissions

## Security Notes

- Never commit `.env` file to version control
- Keep `APP_DEBUG=false` in production
- Use strong `APP_KEY`
- Regularly update dependencies: `composer update` and `npm update`
- Keep PHP and server software updated
- Use HTTPS (SSL/TLS) in production
- Set proper file permissions

## Performance Optimization

- Enable OPcache in PHP
- Use Redis/Memcached for caching (optional)
- Configure CDN for static assets (optional)
- Enable Gzip compression in web server
- Use database query caching
- Optimize images before uploading

