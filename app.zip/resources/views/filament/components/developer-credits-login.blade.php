<div class="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800">
    <div class="flex flex-col items-center justify-center gap-1">
        <p class="text-xs text-gray-500 dark:text-gray-400 text-center">
            Website design & development by
        </p>
        <a href="#" class="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 transition-colors duration-200">
            olexto Digital Solutions (Pvt) Ltd
        </a>
    </div>
</div>

