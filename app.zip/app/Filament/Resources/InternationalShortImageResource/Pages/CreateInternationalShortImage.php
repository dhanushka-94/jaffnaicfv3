<?php

namespace App\Filament\Resources\InternationalShortImageResource\Pages;

use App\Filament\Resources\InternationalShortImageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateInternationalShortImage extends CreateRecord
{
    protected static string $resource = InternationalShortImageResource::class;
}


