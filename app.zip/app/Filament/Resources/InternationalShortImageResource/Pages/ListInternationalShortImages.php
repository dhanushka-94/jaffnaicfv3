<?php

namespace App\Filament\Resources\InternationalShortImageResource\Pages;

use App\Filament\Resources\InternationalShortImageResource;
use Filament\Resources\Pages\ListRecords;

class ListInternationalShortImages extends ListRecords
{
    protected static string $resource = InternationalShortImageResource::class;
}


