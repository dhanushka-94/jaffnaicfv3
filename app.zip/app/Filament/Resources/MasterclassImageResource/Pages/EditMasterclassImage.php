<?php

namespace App\Filament\Resources\MasterclassImageResource\Pages;

use App\Filament\Resources\MasterclassImageResource;
use Filament\Resources\Pages\EditRecord;

class EditMasterclassImage extends EditRecord
{
    protected static string $resource = MasterclassImageResource::class;
}


