<?php

namespace App\Filament\Resources\DebutFilmImageResource\Pages;

use App\Filament\Resources\DebutFilmImageResource;
use Filament\Resources\Pages\ListRecords;

class ListDebutFilmImages extends ListRecords
{
    protected static string $resource = DebutFilmImageResource::class;
}


