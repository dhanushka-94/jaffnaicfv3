<?php

namespace App\Filament\Resources\DebutFilmImageResource\Pages;

use App\Filament\Resources\DebutFilmImageResource;
use Filament\Resources\Pages\EditRecord;

class EditDebutFilmImage extends EditRecord
{
    protected static string $resource = DebutFilmImageResource::class;
}


