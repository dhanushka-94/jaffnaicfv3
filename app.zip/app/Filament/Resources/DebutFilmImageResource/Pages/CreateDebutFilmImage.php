<?php

namespace App\Filament\Resources\DebutFilmImageResource\Pages;

use App\Filament\Resources\DebutFilmImageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDebutFilmImage extends CreateRecord
{
    protected static string $resource = DebutFilmImageResource::class;
}


