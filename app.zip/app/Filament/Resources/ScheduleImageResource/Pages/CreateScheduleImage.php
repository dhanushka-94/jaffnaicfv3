<?php

namespace App\Filament\Resources\ScheduleImageResource\Pages;

use App\Filament\Resources\ScheduleImageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateScheduleImage extends CreateRecord
{
    protected static string $resource = ScheduleImageResource::class;
}


