<?php

namespace App\Filament\Resources\ScheduleImageResource\Pages;

use App\Filament\Resources\ScheduleImageResource;
use Filament\Resources\Pages\EditRecord;

class EditScheduleImage extends EditRecord
{
    protected static string $resource = ScheduleImageResource::class;
}


