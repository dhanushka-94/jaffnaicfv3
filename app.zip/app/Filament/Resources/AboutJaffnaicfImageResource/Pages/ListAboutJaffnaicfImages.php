<?php

namespace App\Filament\Resources\AboutJaffnaicfImageResource\Pages;

use App\Filament\Resources\AboutJaffnaicfImageResource;
use Filament\Resources\Pages\ListRecords;

class ListAboutJaffnaicfImages extends ListRecords
{
    protected static string $resource = AboutJaffnaicfImageResource::class;
}

