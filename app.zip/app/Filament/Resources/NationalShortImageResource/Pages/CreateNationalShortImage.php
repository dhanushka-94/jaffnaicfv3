<?php

namespace App\Filament\Resources\NationalShortImageResource\Pages;

use App\Filament\Resources\NationalShortImageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateNationalShortImage extends CreateRecord
{
    protected static string $resource = NationalShortImageResource::class;
}


