<?php

namespace App\Filament\Resources\NewAsianCurrentImageResource\Pages;

use App\Filament\Resources\NewAsianCurrentImageResource;
use Filament\Resources\Pages\ListRecords;

class ListNewAsianCurrentImages extends ListRecords
{
    protected static string $resource = NewAsianCurrentImageResource::class;
}


