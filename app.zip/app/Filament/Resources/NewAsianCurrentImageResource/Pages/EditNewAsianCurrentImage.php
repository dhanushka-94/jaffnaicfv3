<?php

namespace App\Filament\Resources\NewAsianCurrentImageResource\Pages;

use App\Filament\Resources\NewAsianCurrentImageResource;
use Filament\Resources\Pages\EditRecord;

class EditNewAsianCurrentImage extends EditRecord
{
    protected static string $resource = NewAsianCurrentImageResource::class;
}


