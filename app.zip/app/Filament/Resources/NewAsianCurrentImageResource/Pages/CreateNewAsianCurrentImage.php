<?php

namespace App\Filament\Resources\NewAsianCurrentImageResource\Pages;

use App\Filament\Resources\NewAsianCurrentImageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateNewAsianCurrentImage extends CreateRecord
{
    protected static string $resource = NewAsianCurrentImageResource::class;
}


