<?php

namespace App\Filament\Resources\PartnerCategoryResource\Pages;

use App\Filament\Resources\PartnerCategoryResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePartnerCategory extends CreateRecord
{
    protected static string $resource = PartnerCategoryResource::class;
}

