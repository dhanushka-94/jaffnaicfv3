<?php

namespace App\Filament\Resources\JuryShortImageResource\Pages;

use App\Filament\Resources\JuryShortImageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateJuryShortImage extends CreateRecord
{
    protected static string $resource = JuryShortImageResource::class;
}


