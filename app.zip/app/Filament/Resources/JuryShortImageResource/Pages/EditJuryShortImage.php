<?php

namespace App\Filament\Resources\JuryShortImageResource\Pages;

use App\Filament\Resources\JuryShortImageResource;
use Filament\Resources\Pages\EditRecord;

class EditJuryShortImage extends EditRecord
{
    protected static string $resource = JuryShortImageResource::class;
}


