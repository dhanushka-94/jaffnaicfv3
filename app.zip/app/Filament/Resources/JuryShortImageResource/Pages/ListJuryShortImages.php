<?php

namespace App\Filament\Resources\JuryShortImageResource\Pages;

use App\Filament\Resources\JuryShortImageResource;
use Filament\Resources\Pages\ListRecords;

class ListJuryShortImages extends ListRecords
{
    protected static string $resource = JuryShortImageResource::class;
}


