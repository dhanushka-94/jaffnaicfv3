<?php

namespace App\Filament\Resources\ProgrammeImageResource\Pages;

use App\Filament\Resources\ProgrammeImageResource;
use Filament\Resources\Pages\ListRecords;

class ListProgrammeImages extends ListRecords
{
    protected static string $resource = ProgrammeImageResource::class;
}


