<?php

namespace App\Filament\Resources\ProgrammeImageResource\Pages;

use App\Filament\Resources\ProgrammeImageResource;
use Filament\Resources\Pages\EditRecord;

class EditProgrammeImage extends EditRecord
{
    protected static string $resource = ProgrammeImageResource::class;
}


