<?php

namespace App\Filament\Resources\ProgrammeImageResource\Pages;

use App\Filament\Resources\ProgrammeImageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateProgrammeImage extends CreateRecord
{
    protected static string $resource = ProgrammeImageResource::class;
}


