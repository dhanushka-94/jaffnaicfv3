<?php

namespace App\Filament\Resources\JuryDebutImageResource\Pages;

use App\Filament\Resources\JuryDebutImageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateJuryDebutImage extends CreateRecord
{
    protected static string $resource = JuryDebutImageResource::class;
}


