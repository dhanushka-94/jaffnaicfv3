<?php

namespace App\Filament\Resources\JuryDebutImageResource\Pages;

use App\Filament\Resources\JuryDebutImageResource;
use Filament\Resources\Pages\EditRecord;

class EditJuryDebutImage extends EditRecord
{
    protected static string $resource = JuryDebutImageResource::class;
}


