<?php

namespace App\Filament\Resources\JuryDebutImageResource\Pages;

use App\Filament\Resources\JuryDebutImageResource;
use Filament\Resources\Pages\ListRecords;

class ListJuryDebutImages extends ListRecords
{
    protected static string $resource = JuryDebutImageResource::class;
}


