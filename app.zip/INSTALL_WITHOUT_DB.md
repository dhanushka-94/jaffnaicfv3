# Installation Without Database - Step by Step

## Step 1: Install Dependencies (Skip Database Connection)

Run these commands to install without connecting to database:

```bash
# Install Composer dependencies without running scripts
composer install --no-scripts --optimize-autoloader --no-dev

# Generate autoloader manually
composer dump-autoload --optimize
```

This will:
- ✅ Install all PHP packages
- ✅ Skip database connection attempts
- ✅ Optimize autoloader
- ✅ Complete successfully even without database

## Step 2: Install Node Dependencies and Build Assets

```bash
# Install npm packages
npm install

# Build production assets
npm run build
```

## Step 3: Add Database Credentials

Now edit your `.env` file and add your database credentials:

```env
DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=your_database_name
DB_USERNAME=your_database_username
DB_PASSWORD=your_database_password
```

## Step 4: Generate Application Key

```bash
php artisan key:generate
```

## Step 5: Run Database Setup

```bash
# Run migrations to create tables
php artisan migrate --force

# (Optional) Seed initial data
php artisan db:seed --class=FreshDatabaseSeeder
```

## Step 6: Create Storage Link

```bash
php artisan storage:link
```

## Step 7: Optimize for Production

```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache
```

## Step 8: Set Permissions (Linux/Unix)

```bash
chmod -R 755 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

## Complete Installation Order

```bash
# 1. Install dependencies (no database needed)
composer install --no-scripts --optimize-autoloader --no-dev
composer dump-autoload --optimize

# 2. Install and build assets
npm install
npm run build

# 3. Add database credentials to .env file
# (Edit .env manually)

# 4. Generate app key
php artisan key:generate

# 5. Setup database
php artisan migrate --force

# 6. Create storage link
php artisan storage:link

# 7. Optimize
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache
```

## Notes

- The `--no-scripts` flag prevents Laravel from trying to connect to database during installation
- After adding database credentials, all Laravel commands will work normally
- The code has been updated to handle missing database gracefully, so even if something tries to connect, it won't crash

