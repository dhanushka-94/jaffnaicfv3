

<?php $__env->startSection('title', 'National Short Films ' . $year . ' — ' . ($__site?->site_name ?? 'Jaffna International Cinema Festival')); ?>
<?php $__env->startSection('meta_description', 'National Short Films from ' . $year . ' edition of the Jaffna International Cinema Festival.'); ?>

<?php $__env->startSection('content'); ?>
	<section class="container-full py-16">
		<?php if (isset($component)) { $__componentOriginalfbde74261cbfa24c5ed214e41d029630 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbde74261cbfa24c5ed214e41d029630 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.year-selector','data' => ['currentYear' => $currentYear,'selectedYear' => $year,'availableYears' => $availableYears,'routeName' => 'archive.programme.national-short-films','routeParams' => ['year' => $year]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('year-selector'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['currentYear' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentYear),'selectedYear' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($year),'availableYears' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($availableYears),'routeName' => 'archive.programme.national-short-films','routeParams' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['year' => $year])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbde74261cbfa24c5ed214e41d029630)): ?>
<?php $attributes = $__attributesOriginalfbde74261cbfa24c5ed214e41d029630; ?>
<?php unset($__attributesOriginalfbde74261cbfa24c5ed214e41d029630); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbde74261cbfa24c5ed214e41d029630)): ?>
<?php $component = $__componentOriginalfbde74261cbfa24c5ed214e41d029630; ?>
<?php unset($__componentOriginalfbde74261cbfa24c5ed214e41d029630); ?>
<?php endif; ?>
		<?php if (isset($component)) { $__componentOriginal268064efaa4a3798a4036adddf901915 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal268064efaa4a3798a4036adddf901915 = $attributes; } ?>
<?php $component = App\View\Components\Programme\Gallery::resolve(['title' => 'National Short Films','year' => $year,'active' => $active,'images' => $images,'description' => 'National short films in competition from '.e($year).' edition.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('programme.gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Programme\Gallery::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal268064efaa4a3798a4036adddf901915)): ?>
<?php $attributes = $__attributesOriginal268064efaa4a3798a4036adddf901915; ?>
<?php unset($__attributesOriginal268064efaa4a3798a4036adddf901915); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal268064efaa4a3798a4036adddf901915)): ?>
<?php $component = $__componentOriginal268064efaa4a3798a4036adddf901915; ?>
<?php unset($__componentOriginal268064efaa4a3798a4036adddf901915); ?>
<?php endif; ?>
	</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\resources\views\archive\programme\national-shorts.blade.php ENDPATH**/ ?>