<p
    <?php echo e($attributes->class(['fi-section-header-description'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\vendor\filament\support\resources\views\components\section\description.blade.php ENDPATH**/ ?>