<h2
    <?php echo e($attributes->class(['fi-modal-heading'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\vendor\filament\support\resources\views\components\modal\heading.blade.php ENDPATH**/ ?>