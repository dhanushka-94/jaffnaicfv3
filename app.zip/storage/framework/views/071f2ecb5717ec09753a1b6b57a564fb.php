<?php echo e(\Filament\Support\generate_loading_indicator_html($attributes)); ?>

<?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\vendor\filament\support\resources\views\components\loading-indicator.blade.php ENDPATH**/ ?>