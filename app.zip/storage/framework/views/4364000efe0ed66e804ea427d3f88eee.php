<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\vendor\filament\widgets\resources\views\components\widget.blade.php ENDPATH**/ ?>