<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['currentYear', 'selectedYear', 'availableYears', 'routeName', 'routeParams' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['currentYear', 'selectedYear', 'availableYears', 'routeName', 'routeParams' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="mb-8 md:mb-12" data-aos="fade-up">
	<div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
		<div>
			<h2 class="text-2xl md:text-3xl lg:text-4xl font-display font-bold text-primary">
				<?php echo e($selectedYear); ?> Archive
			</h2>
			<?php if($selectedYear !== $currentYear): ?>
				<p class="mt-2 text-dark/70">Viewing archived content from <?php echo e($selectedYear); ?></p>
			<?php endif; ?>
		</div>
		
		<div class="flex items-center gap-3">
			<label for="year-selector" class="text-sm font-medium text-dark/80">Select Year:</label>
			<select 
				id="year-selector" 
				onchange="window.location.href = this.value"
				class="px-4 py-2 border border-dark/20 rounded-lg bg-white text-dark focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
			>
				<?php $__currentLoopData = $availableYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option 
						value="<?php echo e(route($routeName, array_merge($routeParams, ['year' => $year]))); ?>"
						<?php echo e($year == $selectedYear ? 'selected' : ''); ?>

					>
						<?php echo e($year); ?>

					</option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
	</div>
</div>

<?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\resources\views\components\year-selector.blade.php ENDPATH**/ ?>