

<?php $__env->startSection('title', 'Venues ' . $year . ' — ' . ($__site?->site_name ?? 'Jaffna International Cinema Festival')); ?>
<?php $__env->startSection('meta_description', 'Festival venues from ' . $year . ' edition of the Jaffna International Cinema Festival.'); ?>

<?php $__env->startSection('content'); ?>
	<section class="container-full py-16">
		<?php if (isset($component)) { $__componentOriginalfbde74261cbfa24c5ed214e41d029630 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbde74261cbfa24c5ed214e41d029630 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.year-selector','data' => ['currentYear' => $currentYear,'selectedYear' => $year,'availableYears' => $availableYears,'routeName' => 'archive.venues','routeParams' => ['year' => $year]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('year-selector'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['currentYear' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentYear),'selectedYear' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($year),'availableYears' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($availableYears),'routeName' => 'archive.venues','routeParams' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['year' => $year])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbde74261cbfa24c5ed214e41d029630)): ?>
<?php $attributes = $__attributesOriginalfbde74261cbfa24c5ed214e41d029630; ?>
<?php unset($__attributesOriginalfbde74261cbfa24c5ed214e41d029630); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbde74261cbfa24c5ed214e41d029630)): ?>
<?php $component = $__componentOriginalfbde74261cbfa24c5ed214e41d029630; ?>
<?php unset($__componentOriginalfbde74261cbfa24c5ed214e41d029630); ?>
<?php endif; ?>

		<?php if($venues->isEmpty()): ?>
			<div class="mt-10 bg-white rounded-xl p-6 md:p-10 shadow-soft text-center">
				<h2 class="text-2xl md:text-3xl font-bold tracking-tight">No Venues Data Available</h2>
				<p class="mt-3 text-dark/70 max-w-xl mx-auto">
					Venue information for <?php echo e($year); ?> is not available in the archive.
				</p>
			</div>
		<?php else: ?>
			<p class="mt-4 text-dark/70 max-w-2xl">Screenings and events took place across several venues in Jaffna during <?php echo e($year); ?>.</p>
			<div class="mt-10 grid gap-8 lg:grid-cols-2">
				<?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="bg-white rounded-xl p-6 shadow-soft">
						<h3 class="text-xl font-semibold"><?php echo e($venue->name); ?></h3>
						<?php if($venue->address): ?>
							<div class="mt-2 text-dark/80 leading-relaxed">
								<?php echo nl2br(e($venue->address)); ?>

							</div>
						<?php endif; ?>
						<?php if($venue->contacts): ?>
							<div class="mt-1 text-dark/80 leading-relaxed">
								<?php echo e($venue->contacts); ?>

							</div>
						<?php endif; ?>
						<?php if($venue->map_iframe): ?>
							<div class="mt-4 map-embed rounded-lg overflow-hidden">
								<?php echo $venue->map_iframe; ?>

							</div>
						<?php endif; ?>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?>
	</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\resources\views\archive\venues.blade.php ENDPATH**/ ?>