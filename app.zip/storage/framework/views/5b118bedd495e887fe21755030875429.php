

<?php $__env->startSection('title', 'Gallery — ' . ($__site?->site_name ?? 'Jaffna International Cinema Festival')); ?>
<?php $__env->startSection('meta_description', 'Image gallery showcasing moments from the Jaffna International Cinema Festival.'); ?>

<?php $__env->startSection('content'); ?>
	<section class="container-full py-16">
		<h1 class="section-title" data-aos="fade-up">Gallery</h1>
		<p class="mt-4 text-dark/70 max-w-2xl" data-aos="fade-up" data-aos-delay="100">
			Explore moments from the Jaffna International Cinema Festival through our image gallery.
		</p>

		<?php if($images->isEmpty()): ?>
			<div class="mt-10 text-center py-12">
				<p class="text-dark/70 text-lg">Gallery images will appear here once they are published.</p>
			</div>
		<?php else: ?>
			<div class="mt-10 grid gap-6" data-aos="fade-up" data-aos-delay="200">
				<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php ($allImages = $galleryItem->getAllImagePaths()); ?>
					<?php if(!empty($allImages)): ?>
						<div class="bg-white rounded-xl p-6 md:p-8 shadow-soft">
							<?php if($galleryItem->title): ?>
								<h2 class="text-2xl md:text-3xl font-display font-bold mb-2"><?php echo e($galleryItem->title); ?></h2>
							<?php endif; ?>
							<?php if($galleryItem->description): ?>
								<p class="text-dark/70 mb-6 max-w-3xl"><?php echo e($galleryItem->description); ?></p>
							<?php endif; ?>
							<div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
								<?php $__currentLoopData = $allImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagePath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="group bg-white rounded-lg overflow-hidden shadow-soft hover:shadow-xl transition-all duration-300 border border-black/5">
										<div class="aspect-square bg-black/5 relative overflow-hidden">
											<?php if(file_exists(storage_path('app/public/' . $imagePath))): ?>
												<img 
													src="<?php echo e(asset('storage/' . $imagePath)); ?>" 
													alt="<?php echo e($galleryItem->title ?? 'Gallery Image ' . $loop->parent->iteration . '-' . $loop->iteration); ?>" 
													class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
													loading="lazy"
												>
											<?php else: ?>
												<div class="text-center p-4 text-dark/40 flex items-center justify-center h-full">
													<svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
														<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
													</svg>
												</div>
											<?php endif; ?>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?>
	</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\resources\views\gallery.blade.php ENDPATH**/ ?>