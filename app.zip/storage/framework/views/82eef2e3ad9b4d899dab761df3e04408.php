<div <?php echo e($attributes->class(['fi-btn-group'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\vendor\filament\support\resources\views\components\button\group.blade.php ENDPATH**/ ?>