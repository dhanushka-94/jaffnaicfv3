

<?php $__env->startSection('title', 'Team ' . $year . ' — ' . ($__site?->site_name ?? 'Jaffna International Cinema Festival')); ?>
<?php $__env->startSection('meta_description', 'Meet the team from ' . $year . ' edition of the Jaffna International Cinema Festival.'); ?>

<?php $__env->startSection('content'); ?>
	<section class="container-full py-16">
		<?php if (isset($component)) { $__componentOriginalfbde74261cbfa24c5ed214e41d029630 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbde74261cbfa24c5ed214e41d029630 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.year-selector','data' => ['currentYear' => $currentYear,'selectedYear' => $year,'availableYears' => $availableYears,'routeName' => 'archive.team','routeParams' => ['year' => $year]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('year-selector'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['currentYear' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentYear),'selectedYear' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($year),'availableYears' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($availableYears),'routeName' => 'archive.team','routeParams' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['year' => $year])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbde74261cbfa24c5ed214e41d029630)): ?>
<?php $attributes = $__attributesOriginalfbde74261cbfa24c5ed214e41d029630; ?>
<?php unset($__attributesOriginalfbde74261cbfa24c5ed214e41d029630); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbde74261cbfa24c5ed214e41d029630)): ?>
<?php $component = $__componentOriginalfbde74261cbfa24c5ed214e41d029630; ?>
<?php unset($__componentOriginalfbde74261cbfa24c5ed214e41d029630); ?>
<?php endif; ?>

		<?php if($groups->isEmpty()): ?>
			<div class="mt-10 bg-white rounded-xl p-6 md:p-10 shadow-soft text-center">
				<h2 class="text-2xl md:text-3xl font-bold tracking-tight">No Team Data Available</h2>
				<p class="mt-3 text-dark/70 max-w-xl mx-auto">
					Team information for <?php echo e($year); ?> is not available in the archive.
				</p>
			</div>
		<?php else: ?>
			<div class="mt-10 grid gap-8">
				<?php
					// Get all roles from groups (including those not in roleOrder)
					$allRoles = $groups->keys();
					// Merge with roleOrder to maintain order, then add any missing roles
					$displayRoles = collect($roleOrder ?? [])->keys()->merge($allRoles)->unique();
				?>
				
				<?php $__currentLoopData = $displayRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php ($members = $groups->get($role, collect())); ?>
					<?php if($members->isNotEmpty()): ?>
						<div class="bg-white rounded-xl p-6 md:p-8 shadow-soft">
							<?php if(isset($roleOrder[$role])): ?>
								<h2 class="text-2xl md:text-3xl font-bold"><?php echo e($roleOrder[$role]); ?></h2>
							<?php else: ?>
								<h2 class="text-2xl md:text-3xl font-bold uppercase tracking-wide"><?php echo e($role); ?></h2>
							<?php endif; ?>

							<?php if($role === 'Director' || $role === 'Manager'): ?>
								<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="mt-4">
										<div class="text-lg font-semibold"><?php echo e($person->name); ?></div>
										<?php if($person->role): ?>
										<div class="text-xs mt-1 inline-flex items-center gap-2">
											<span class="px-2 py-1 rounded bg-primary/10 text-primary uppercase tracking-wide"><?php echo e($person->role); ?></span>
										</div>
										<?php endif; ?>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php elseif($role === 'Consultant'): ?>
								<div class="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
									<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="p-4 rounded-lg border border-black/5 hover:shadow-soft transition">
											<div class="font-semibold"><?php echo e($person->name); ?></div>
											<div class="text-xs mt-1 text-dark/60 uppercase tracking-wide">Consultant</div>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							<?php elseif($role === 'Advisory Committee'): ?>
								<ul class="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
									<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><?php echo e($person->name); ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							<?php elseif($role === 'Festival Team'): ?>
								<ul class="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
									<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="p-3 rounded-lg border border-black/5"><?php echo e($person->name); ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							<?php elseif($role === 'Coordinator — Colombo' || $role === 'Coordinator — Jaffna'): ?>
								<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="mt-4 p-4 rounded-lg border border-black/5 w-full sm:w-auto">
										<div class="font-semibold"><?php echo e($person->name); ?></div>
										<div class="text-xs mt-1 text-dark/60 uppercase tracking-wide"><?php echo e($person->role); ?></div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
								
								<ul class="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
									<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="p-3 rounded-lg border border-black/5">
											<div class="font-semibold"><?php echo e($person->name); ?></div>
											<?php if($person->role && !isset($roleOrder[$role])): ?>
												<div class="text-xs mt-1 text-dark/60 uppercase tracking-wide"><?php echo e($person->role); ?></div>
											<?php endif; ?>
										</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?>
	</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\resources\views\archive\team.blade.php ENDPATH**/ ?>