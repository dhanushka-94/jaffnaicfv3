

<?php $__env->startSection('title', 'PROGRAMME — NEW ASIAN CURRENTS'); ?>
<?php $__env->startSection('meta_description', 'New Asian Currents image gallery for the current edition of the Jaffna International Cinema Festival.'); ?>

<?php $__env->startSection('content'); ?>
	<?php if (isset($component)) { $__componentOriginal268064efaa4a3798a4036adddf901915 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal268064efaa4a3798a4036adddf901915 = $attributes; } ?>
<?php $component = App\View\Components\Programme\Gallery::resolve(['title' => 'New Asian Currents','year' => $year,'active' => $active,'images' => $images,'description' => 'Asian cinema that explores new voices, perspectives, and cinematic forms.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('programme.gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Programme\Gallery::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal268064efaa4a3798a4036adddf901915)): ?>
<?php $attributes = $__attributesOriginal268064efaa4a3798a4036adddf901915; ?>
<?php unset($__attributesOriginal268064efaa4a3798a4036adddf901915); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal268064efaa4a3798a4036adddf901915)): ?>
<?php $component = $__componentOriginal268064efaa4a3798a4036adddf901915; ?>
<?php unset($__componentOriginal268064efaa4a3798a4036adddf901915); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dhanushka\Desktop\Jaffna ICF\jaffnaicfweb25V3\resources\views\programme\new-asian-currents.blade.php ENDPATH**/ ?>