<?php
/**
 * Temporary Migration Runner for Plesk
 * 
 * INSTRUCTIONS:
 * 1. Upload this file to your domain root
 * 2. Access via browser: https://yourdomain.com/run-migrations.php
 * 3. DELETE this file immediately after migrations complete!
 * 
 * SECURITY WARNING: This file allows running migrations via web.
 * Remove it immediately after use!
 */

// Security check - remove this in production or add IP restriction
if (!isset($_GET['run']) || $_GET['run'] !== 'migrate') {
    die('Access denied. Add ?run=migrate to URL to proceed.');
}

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

echo "<h2>Running Migrations...</h2>";
echo "<pre>";

try {
    // Run migrations
    Artisan::call('migrate', ['--force' => true]);
    echo Artisan::output();
    echo "\n✅ Migrations completed successfully!\n";
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "\nStack trace:\n";
    echo $e->getTraceAsString();
}

echo "</pre>";
echo "<p><strong>⚠️ IMPORTANT: Delete this file (run-migrations.php) immediately!</strong></p>";

